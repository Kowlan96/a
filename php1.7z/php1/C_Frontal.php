<?php

    $getPost=array_merge($_GET, $_POST, $_FILES);


    if(isset($getPost['controlador']) && $getPost['controlador']!= '' ){
        //RECIBO CONTROLADOR
        
        $controlador='C_'.$getPost['controlador'];

        if(file_exists('./Controllers/'.$controlador.'.php')){
            //EXISTE EL CONTROLADOR
                $metodo = $getPost['metodo'];

                //require_once './Controllers/'.$controlador.'.php'; //Podrian valernos las dos
                require_once "./Controllers/$controlador.php";
                
                $objControlador= new $controlador();

                if(method_exists($objControlador, $metodo)){

                    $objControlador-> $metodo($getPost);//LLAMAMOS AL METODO
                }else{
                    echo 'Error CF-03'; //NO EXISTE EL METODO
                }
        }else{
            echo 'Error CF-NoFileController-02'; //NO EXISTE EL FICHERO DE CONTROLADOR
        }

    }else{
        echo 'Error CF-01';
        //NO RECIBO CONTROLADOR
    }

    require_once './Controllers/C_User.php';//Aqui llamamos al controller del usuario 

    $controlador = new C_User();
    $controlador->getPrueba() //AQUI PARA LLAMAR A UN METODO ES LLAMAR A LA CLASE Y LUEGO -> (FLECHA) Y EL METODO

?>