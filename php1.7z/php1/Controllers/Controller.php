<?php

class Controller{
    function __construct(){
        //CONSTRUCTOR DE LA CLASE 
    }
} //Fin clase Controller 

?>