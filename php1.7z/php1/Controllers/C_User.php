<?php
    require_once 'Controllers/Controller.php';
    
    class C_User extends Controller{
        public function __construct(){
            parent::__construct(); //ESTO LLAMARIA AL CONSTRUCTOR DEL PADRE PARA EJECUTARLO
        }

        public function getPrueba($datos = array()){//$datos = array() es un parametro opcional, creando la variable, si no se asignase esperaria obligatoriamente un parámetro
            echo 'Hoñi de nuevo!';
        }

    }//FIN CLASE

?>