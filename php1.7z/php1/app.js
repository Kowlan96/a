function obtenerVista(controlador, metodo, destino){ //ESTA FUNCION LLAMA AL CONTROLADOR FRONTAL MEDIANTE UN FETCH
    let opciones = {method: "GET", };
    let parametros = "controlador=" + controlador + "&metodo=" + metodo; //ESTA VARIABLE DE PARAMETROS AÑADE EL CONTROLADOR Y CONCATENA EL METODO PARA SEPARAR CADA PARAMETRO DE LA URL
    fetch("C_Frontal.php?" + parametros, opciones)
    .then(res => {
        if(res.ok){
            return res.text();
        }
        throw new Error(res.status);
    })
    .then(vista => {
        document.getElementById(destino).innerHTML=vista;
    })
    .catch(err=> {
        console.error("Error al pedir vista", err.message);
    })
}